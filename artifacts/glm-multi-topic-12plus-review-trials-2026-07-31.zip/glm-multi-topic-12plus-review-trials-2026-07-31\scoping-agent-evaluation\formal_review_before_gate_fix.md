## 综述：LLM Agent 能力评价与基准评估现状

### 1. 引言
随着大语言模型（LLM）从单一文本生成向具备自主决策能力的智能体演进，如何科学、全面地评价其规划、工具使用、记忆、协作及长期任务能力成为关键挑战。现有的基准测试在任务设计、指标选择、可复现性及有效性风险方面存在显著差异。本文综述了相关研究，旨在分析现有评价体系的局限性及未来方向。

### 2. 评价维度与框架
LLM Agent 的评价通常围绕其核心架构模块展开，包括规划、记忆、工具使用及协作能力。

*   **规划能力**：规划是 Agent 实现长期目标的核心。现有研究指出，LLM 具备内在的推理能力，能够通过 CoT（思维链）进行任务分解 [P3]。然而，在复杂的多步任务中，单纯依赖模型内在推理存在局限性，往往需要引入外部规划工具或机制来增强鲁棒性 [P10]。
*   **记忆系统**：记忆模块分为短期记忆和长期记忆。短期记忆通常用于处理当前上下文，而长期记忆则用于积累历史经验。研究表明，混合记忆结构（结合统一记忆与长短时记忆）能有效提升 Agent 的任务解决能力 [P4]。
*   **工具使用**：工具使用能力是 Agent 赋能现实世界的关键。评价通常关注“何时调用”、“调用哪个工具”以及“如何使用工具”三个维度 [P10]。基准测试如 API-Bank 和 ToolBench 专门针对 API 调用的准确性、检索准确率及参数匹配度进行评估 [P8, P9]。

### 3. 基准测试与任务设计
为了量化上述能力，学术界提出了多种基准测试，涵盖了从通用任务到特定领域的广泛场景。

*   **通用与多模态基准**：MMLU、MATH 等基准主要评估 LLM 的通用推理能力，这些能力是 Agent 进行规划的基础 [P1, P2]。对于多模态 Agent，评估需关注其在视觉或音频输入下的工具调用能力 [P10]。
*   **工具使用专项基准**：API-Bank 构建了包含 73 个真实 API 的基准，评估模型从“调用”到“规划+检索+调用”的进阶能力 [P8]。研究发现，即使是 GPT-3.5，在 API 检索和规划方面的能力也显著弱于调用能力，且主要错误类型集中在检索失败而非参数错误 [P8]。
*   **长期与复杂任务基准**：针对长期任务，现有基准如 AgentDojo、FlowBench 等开始探索多轮交互和动态环境下的评估 [P9]。然而，大多数基准仍侧重于单次交互或短周期任务，难以捕捉 Agent 在长时间运行中的性能漂移或累积效应 [P9]。

### 4. 评价指标与评估方法
评价指标的选择直接影响评估的有效性，主要分为客观指标和主观指标。

*   **客观指标**：包括任务成功率、执行准确率、工具调用准确率（如 MRR, NDCG）以及 Pass@k（一致性评估） [P9]。这些指标易于自动化，但往往难以评估 Agent 的输出质量或推理过程。
*   **主观指标**：包括人类反馈、用户满意度及 Turing Test [P5, P6]。在社交模拟或心理咨询等场景中，主观评价对于衡量 Agent 的“拟人化”程度至关重要 [P4, P11]。
*   **LLM-as-a-Judge**：为了解决主观评价的成本问题，研究者开始使用更强的 LLM 作为裁判来评估 Agent 的行为 [P9]。然而，这种方法引入了新的复杂性，且可能受到“Hyper-accuracy distortion”（过度精确化偏差）的影响 [P4, P5]。

### 5. 可复现性与有效性风险
尽管基准测试层出不穷，但在可复现性和有效性方面仍面临严峻挑战。

*   **可复现性问题**：许多基准测试缺乏开源代码或详细的数据集描述，导致结果难以复现 [P3, P5]。此外，LLM 的随机性使得在相同任务上多次运行可能产生不同结果，增加了评估的不确定性 [P9]。
*   **有效性风险**：
    *   **数据偏差与过拟合**：基准测试数据集可能包含训练数据，导致模型通过记忆而非推理获得高分 [P2]。
    *   **环境封闭性**：现有基准多在封闭环境中运行，缺乏对真实世界复杂性和动态性的考量 [P6]。
    *   **评估指标局限**：单一的准确率指标可能掩盖 Agent 在安全性、公平性或长期一致性方面的缺陷 [P9]。

### 6. 结论
LLM Agent 的评价正处于从单一任务测试向多维度、长周期评估过渡的阶段。虽然现有的基准测试在工具使用和通用推理方面取得了显著进展，但在长期记忆管理、多 Agent 协作以及真实世界动态环境下的评估仍存在不足。未来的研究需要开发更具鲁棒性、可复现性且能反映真实复杂场景的评估框架。

## 参考来源

- [P1] Humza Naveed, Asad Ullah Khan, Shi Qiu, Muhammad Saqib, Saeed Anwar, Muhammad Usman, Akhtar, Naveed, Nick Barnes, Ajmal Mian. A Comprehensive Overview of Large Language Models. 2023. https://arxiv.org/abs/2307.06435
- [P2] Yupeng Chang, Xu Wang, Jindong Wang, Yuan-Hsuan Wu, Linyi Yang, Kaijie Zhu, Hao Chen, Xiaoyuan Yi, Cunxiang Wang, Yidong Wang, Wei Ye, Yue Zhang, Yi Chang, Philip S. Yu, Qiang Yang, Xing Xie. A Survey on Evaluation of Large Language Models. 2023. https://arxiv.org/abs/2307.03109
- [P3] Wayne Xin Zhao, Kun Zhou, Junyi Li, Tianyi Tang, Zican Dong, Yupeng Hou, Beichen Zhang, Yingqian Min, Junjie Zhang, Peiyu Liu, Xiaolei Wang, Yifan Du, Yushuo Chen, Yushuo Chen, Zhipeng Chen, Jinhao Jiang, Ruiyang Ren, Yifan Li, Xinyu Tang, Peiyu Liu, Yiwen Hu, Jian‐Yun Nie, Ji-Rong Wen. A Survey of Large Language Models. 2026. https://arxiv.org/abs/2303.18223
- [P4] Lei Wang, Chen Ma, Xueyang Feng, Zeyu Zhang, Hao Yang, Jingsen Zhang, Zhiyuan Chen, Jiakai Tang, Xu Chen, Yankai Lin, Wayne Xin Zhao, Zhewei Wei, Ji-Rong Wen. A survey on large language model based autonomous agents. 2024. https://doi.org/10.1007/s11704-024-40231-1
- [P5] Lei Wang, Chen Ma, Xueyang Feng, Zeyu Zhang, Hao Yang, Jingsen Zhang, Zhiyuan Chen, Jiakai Tang, Xu Chen, Yankai Lin, Wayne Xin Zhao, Zhewei Wei, Ji-Rong Wen. A Survey on Large Language Model based Autonomous Agents. 2023. https://arxiv.org/abs/2308.11432
- [P6] Zhiheng Xi, Wen-Xiang Chen, Xin Guo, Wei He, Yiwen Ding, Boyang Hong, Ming Zhang, Junzhe Wang, Senjie Jin, Enyu Zhou, Rui Zheng, Xiaoran Fan, Xiao Wang, Limao Xiong, Yuhao Zhou, Weiran Wang, Changhao Jiang, Yicheng Zou, Xiangyang Liu, Zhangyue Yin, Shihan Dou, Rongxiang Weng, Wensen Cheng, Qi Zhang, Wenjuan Qin, Yongyan Zheng, Xipeng Qiu, Huang, Xuanjing, Tao Gui. The Rise and Potential of Large Language Model Based Agents: A Survey. 2023. https://arxiv.org/abs/2309.07864
- [P7] Yunfan Gao, Yun Xiong, Xinyu Gao, Kangxiang Jia, Jinliu Pan, Yuxi Bi, Yi Dai, Jiawei Sun, Wang, Meng, Wang, Haofen. Retrieval-Augmented Generation for Large Language Models: A Survey. 2023. https://arxiv.org/abs/2312.10997
- [P8] Minghao Li, Yingxiu Zhao, Bowen Yu, Feifan Song, Hangyu Li, Haiyang Yu, Zhoujun Li, Fei Huang, Yongbin Li. API-Bank: A Comprehensive Benchmark for Tool-Augmented LLMs. 2023. https://doi.org/10.18653/v1/2023.emnlp-main.187
- [P9] Mahmoud Mohammadi, Yipeng Li, Jane C. Lo, Wendy Yip. Evaluation and Benchmarking of LLM Agents: A Survey. 2025. https://arxiv.org/abs/2507.21504
- [P10] Weikai Xu, Chengrui Huang, Shen Gao, Shuo Shang. LLM-Based Agents for Tool Learning: A Survey. 2025. https://doi.org/10.1007/s41019-025-00296-9
- [P11] Chen Gao, Xiaochong Lan, Nian Li, Yuan Yuan, Jingtao Ding, Zhilun Zhou, Fengli Xu, Yong Li. Large language models empowered agent-based modeling and simulation: a survey and perspectives. 2024. https://doi.org/10.1057/s41599-024-03611-3
- [P12] Nikita Mehandru, Brenda Y. Miao, Eduardo Rodriguez Almaraz, Madhumita Sushil, Atul J. Butte, Ahmed M. Alaa. Evaluating large language models as agents in the clinic. 2024. https://doi.org/10.1038/s41746-024-01083-y
